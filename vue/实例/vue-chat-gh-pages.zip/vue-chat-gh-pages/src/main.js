import app from './components/app';

Vue.config.debug = true;

new Vue(app);