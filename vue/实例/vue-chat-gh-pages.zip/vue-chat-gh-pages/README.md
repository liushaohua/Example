# Chat by Vue + Webpack

[Live demo](http://coffcer.github.io/vue-chat/)

<img width="600" height="400" src="http://coffcer.github.io/vue-chat/dist/images/intro.jpg">

### Setup

```
npm install

# build:
npm run build

# start the server and watch (localhost:8080)
npm run dev
```
